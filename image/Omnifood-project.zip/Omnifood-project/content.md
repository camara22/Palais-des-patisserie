### Omnifood

## À propos d'Omnifood

Nous sommes d'abord une entreprise technologique, mais avec un objectif majeur de bien-être des consommateurs grâce à une alimentation saine. La plupart des gens sont très occupés avec leur travail, leur famille et leurs amis, et d'autres activités importantes, ce qui ne laisse pas beaucoup de temps pour cuisiner. Cela peut entraîner une mauvaise alimentation et des conséquences durables sur la santé. Nous voulons résoudre ce problème en utilisant une approche centrée sur l'IA. Les utilisateurs peuvent utiliser notre application pour sélectionner leur régime alimentaire et les aliments qu'ils aiment ou n'aiment pas, et notre algorithme d'IA créera un plan de repas hebdomadaire personnalisé et individuel. Mais nous ne nous arrêtons pas là. Nous nous associons à des restaurants et d'autres partenaires culinaires pour cuisiner et livrer tous les repas des plans de repas générés, dans des villes sélectionnées. Tout cela sera proposé dans un abonnement mensuel, où les utilisateurs peuvent choisir de recevoir un ou deux repas par jour, chaque jour du mois.

## Branding

Titre : Un repas sain livré à votre porte, chaque jour

Couleur de la marque : #e67e22

## Contenu du site web Omnifood

### Résumé

L'abonnement alimentaire intelligent de 365 jours par an qui vous fera manger sainement à nouveau. Adapté à vos goûts personnels et à vos besoins nutritionnels. Nous avons livré plus de 250 000 repas l'année dernière !

### Caractéristiques d'Omnifood

Ne cuisinez plus jamais ! : Nos abonnements couvrent 365 jours par an, même les jours fériés.
Local et biologique : Nos cuisiniers utilisent uniquement des produits locaux, frais et biologiques pour préparer vos repas.
Aucun gaspillage : Tous nos partenaires utilisent uniquement des contenants réutilisables pour emballer tous vos repas.
Pause à tout moment : Vous partez en vacances ? Suspendez simplement votre abonnement, et nous remboursons les jours non utilisés.

### Comment fonctionne Omnifood

[Afficher de grandes images de l'application]

**Votre dose quotidienne de santé en 3 étapes simples**

Dites-nous ce que vous aimez (et ce que vous n'aimez pas) : Ne perdez plus jamais de temps à réfléchir à ce que vous allez manger ! L'IA d'Omnifood créera un plan de repas hebdomadaire 100 % personnalisé pour vous. Elle s'assure que vous obtenez tous les nutriments et vitamines dont vous avez besoin, quel que soit le régime que vous suivez !

Approuvez votre plan de repas hebdomadaire : Une fois par semaine, approuvez le plan de repas généré pour vous par l'IA d'Omnifood. Vous pouvez changer les ingrédients, échanger des repas entiers, ou même ajouter vos propres recettes.

Recevez des repas à des heures convenables : Les meilleurs chefs en ville cuisineront votre repas sélectionné chaque jour, et nous le livrerons à votre porte à l'heure qui vous convient le mieux. Vous pouvez changer l'horaire de livraison et l'adresse quotidiennement !

### Omnifood fonctionne avec tous les régimes alimentaires

Végétarien
Vegan
Pescetarien
Sans gluten
Sans lactose
Keto
Paléo
Low FODMAP
Adapté aux enfants

### Exemples de repas

**L'IA d'Omnifood choisit parmi plus de 5 000 recettes**

Repas 1 : Gyozas japonais

- Catégorie : Végétarien
- Calories : 650
- NutriScore (Enregistré) : 74
- Note moyenne : 4.9
- Nombre d'avis : 537

Repas 2 : Salade d'avocat

- Catégorie : Vegan et Paléo
- Calories : 400
- NutriScore (Enregistré) : 92
- Note moyenne : 4.8
- Nombre d'avis : 441

### Nous offrons un repas d'essai gratuit

[Créer un formulaire simple pour les utilisateurs pour s'inscrire]

Des repas sains, savoureux et sans tracas vous attendent. Commencez à bien manger dès aujourd'hui. Vous pouvez annuler ou suspendre à tout moment. Et le premier repas est offert !

### Nous avons 2 plans tarifaires

Les prix incluent toutes les taxes applicables. Les utilisateurs peuvent annuler à tout moment.

Starter : 399 $ par mois

- 1 repas par jour
- Commandes entre 11h et 21h
- Livraison gratuite

Complet : 649 $ par mois

- 2 repas par jour
- Commande 24h/24 et 7j/7
- Livraison gratuite
- Accès aux dernières recettes

### Galerie de photos

[Utiliser les 12 photos fournies]

### Témoignages des clients

[Photos des clients incluses]

Des repas peu coûteux, sains et délicieux, sans même avoir à commander manuellement ! C'est vraiment magique. (Dave Bryson)
L'algorithme d'IA est incroyablement bon, il choisit les bons repas pour moi à chaque fois. C'est incroyable de ne plus se soucier de la nourriture ! (Ben Hadley)
Omnifood est un sauveur ! Je viens de créer une entreprise, donc je n'ai pas le temps de cuisiner. Je ne pourrais plus vivre sans mes repas quotidiens maintenant ! (Steve Miller)
J'ai pris Omnifood pour toute la famille, et cela nous libère tellement de temps ! De plus, tout est bio et vegan et sans plastique. (Hannah Smith)

### Section avec les logos des publications en vedette [voir images]

### Informations de contact

Adresse : 623 Harrison St., 2ème étage, San Francisco, CA 94107
Téléphone : 415-201-6370
Email : hello@omnifood.com

Profils sociaux : Instagram, Facebook, Twitter [liens non disponibles encore]

### Liens supplémentaires [liens non disponibles encore]

Créer un compte
Se connecter
Application iOS
Application Android

À propos d'Omnifood
Pour les entreprises
Partenaires culinaires
Carrières

Répertoire des recettes
Centre d'aide
Confidentialité et conditions

######

## Sections

- logo + Navigation
- Featured In
- Features
- How it works
- Diets
- Meals
- CTA
- Pricing
- Gallery
- Testimonials
- Footer
